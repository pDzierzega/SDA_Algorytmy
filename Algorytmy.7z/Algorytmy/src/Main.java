public class Main {

    public static void main(String[] args) {
        String algorithmName = args [0];

    }
}
